var f=document.getElementById("uu").value;
function sum(){
alert(f);
}
