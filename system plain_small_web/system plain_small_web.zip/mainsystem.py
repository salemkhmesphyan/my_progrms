"""
programmer by en:salem khmes phyan
"""
import os
from flask import Flask,render_template,request,send_file,flash,redirect,url_for
import sqlite3
import time
import datetime
from datetime import date
t=time.asctime(time.localtime(time.time()))
x=datetime.datetime.now().hour
s=datetime.datetime.now().minute
a=datetime.datetime.now().second
time1=str(str(x)+":"+str(s)+":"+str(a))
today = str(date.today())
app = Flask(__name__)
app.config['SECRET_KEY'] = "Secret"
APP_ROOT=os.path.dirname(os.path.abspath(__file__))
@app.route("/",methods=['GET','POST'])#methods=['GET']
def login1():
    return render_template(u'system1.html',t=u'صفحة تسجيل الدخول')


@app.route("/puplic",methods=['GET','POST'])#methods=['GET']
def puplic():
    return render_template(u'mainpuplic.html',t=u'main page in puplic',w=time1,d=today)

@app.route("/savedatapuplic",methods=['GET','POST'])
def savedatapuplic():
	data= request.form
	namewe=data["1"]
	timee=data['2']
	datee=data['3']
	reson=data['4']
	remarkk=data['5']
	jobdis=data['6']
	db=sqlite3.connect('compnypuplic.db')
	db.row_factory=sqlite3.Row
	db.execute('create table if not exists addpuplic(ID integer primary Key autoincrement,NameWell text,Time text,Data text,Reason text,Remark text,JobDiscripsion text)')
	db.execute("insert into addpuplic(NameWell,Time,Data,Reason,Remark,JobDiscripsion ) values(?,?,?,?,?,?)",(namewe,timee,datee,reson,remarkk,jobdis))
	db.commit()
	flash('add data secccsyly!')
	return render_template(u'mainpuplic.html',t=u'main page in puplic',w=time1,d=today)


@app.route("/showoperpuplic",methods=['GET','POST'])
def showoperpuplic():
	db=sqlite3.connect('compnypuplic.db')
	db.row_factory=sqlite3.Row
	sd=db.execute("select count(*) totalrows from addpuplic")
	for x in sd:
		p=x[0]
	if p<1:
		return render_template('mainpuplic.html',w=time1,d=today,f='please enter new data',t=u'main page in puplic')
	else:
		shw=db.execute("select * from addpuplic order by ID desc limit 2")
		return render_template('shwpuplic.html',shw=shw,t=u'page show operations')

@app.route("/serchoperationspup",methods=['GET','POST'])
def serchoperationspup():
	return render_template('searcpuplic.html',t='page search operations')


@app.route("/sershowpup",methods=['GET','POST'])#this is sadusahd
def sershowpup():
	sss=[]
	db=sqlite3.connect('compnypuplic.db')
	db.row_factory=sqlite3.Row
	sd=db.execute("select count(*) totalrows from addpuplic")
	for x in sd:
		p=x[0]
	if p<1:return render_template('searcpuplic.html',t=u'page search operations',f='sorry is not operations')
	else:
		data= request.form
		namewe=data["1"]
		db=sqlite3.connect('compnypuplic.db')
		db.row_factory=sqlite3.Row
		sh=db.execute('select * from addpuplic where NameWell like "%{}%"or Data like "%{}%"'.format(namewe,namewe))
		for x in sh:
			sss.append(x['NameWell'])
		flash('The Number Operations is:'+str(len(sss)))
		#g=str(len(sss))
		sh1=db.execute('select * from addpuplic where NameWell like "%{}%"or Data like "%{}%"or ID like "%{}%"'.format(namewe,namewe,namewe))	
		return render_template('searcpuplic.html',t=u'page search operations',sh1=sh1,gg=namewe)

@app.route("/pagemod",methods=['GET','POST'])
def pagemod():
	return render_template('pgmodfis.html',t=u'page modifiy Operations')

@app.route("/pagemodshow",methods=['GET','POST'])
def pagemodshow():
	data= request.form
	namewe=data["11"]
	db=sqlite3.connect('compnypuplic.db')
	db.row_factory=sqlite3.Row
	sh2=db.execute('select * from addpuplic where NameWell="{}"or ID="{}"'.format(namewe,namewe))
	return render_template('pgmodfis.html',sh2=sh2,t=u'page modifiy Operations')


@app.route("/pagemodnow",methods=['GET','POST'])
def pagemodnow():
	data= request.form
	namorigent=data['22']
	idname=data['33']
	namewe=data["1"]
	timee=data['2']
	datee=data['3']
	reson=data['4']
	remarkk=data['5']
	jobdis=data['6']
	db=sqlite3.connect('compnypuplic.db')
	db.row_factory=sqlite3.Row
	db.execute("update addpuplic set NameWell='{}',Time='{}',Data='{}',Reason='{}',Remark='{}',JobDiscripsion='{}' where NameWell='{}' and ID='{}'".format(namewe,timee,datee,reson,remarkk,jobdis,namorigent,idname))
	db.commit()
	flash("modifiy seccssuly!")
	return render_template('pgmodfis.html',t=u'page modifiy Operations')

@app.route("/mangrloin",methods=['GET','POST'])
def mangrloin():
	dd='12345'
	data= request.form
	passw=data['22']
	db=sqlite3.connect('compnypuplic.db')
	db.row_factory=sqlite3.Row
	db.execute('create table if not exists pasmng(ID integer primary Key autoincrement,pas text)')
	db.commit()
	fg=db.execute('select count(*) totalrows from pasmng')

	for x in fg:
		p=x[0]
	if p!=1:
		db.execute("insert into pasmng(pas) values(?)",('0'))
		db.commit()

	se=db.execute("select * from pasmng")
	for j in se:
		g=j['pas']
	if g==passw:

		return render_template('modfnow.html',t=u'page mangrs')
	else:
		flash("The password is not correct")
		return render_template(u'system1.html',t=u'صفحة تسجيل الدخول')



